from gle import *
import _gle as glec
__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES = ['opengltk', 'Numeric']
NONCRITICAL_DEPENDENCIES = ['mglutil']

