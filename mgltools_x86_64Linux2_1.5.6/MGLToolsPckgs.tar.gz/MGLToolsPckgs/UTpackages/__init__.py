#
__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES = ['Numeric']
NONCRITICAL_DEPENDENCIES = ['Pmv', 'opengltk', 'mglutil', 'DejaVu']
